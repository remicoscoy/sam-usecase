# ONLY_SAM > 2023-07-05 12:01pm
https://universe.roboflow.com/test-2lq5m/only_sam

Provided by a Roboflow user
License: CC BY 4.0

