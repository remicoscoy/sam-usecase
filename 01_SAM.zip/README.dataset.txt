# SAM_USECASE_FOR_CROP > 2023-07-03 3:05pm
https://universe.roboflow.com/test-2lq5m/sam_usecase_for_crop

Provided by a Roboflow user
License: CC BY 4.0

