# SAM_USECASE_TEST_SIMPLE > 2023-07-05 11:10am
https://universe.roboflow.com/test-2lq5m/sam_usecase_test_simple

Provided by a Roboflow user
License: CC BY 4.0

